def setup():
    return "Welcome to send-email-python to get stated with gmail please turn on less secure apps in gmail settings."
    