# send-email-python

## Description

The project send-email-python is a python package that is on pypi and will make it easier to send emails with python

## Installation

```bash
pip install send-email-python
```

## Usage

For setup instructions:

```bash
sendmail.setup(<email provider of sender>)
```

Send simple email with a message:

```bash
sendmail.mail(<senders email>,<senders email password>,<recievers email>,<subject>,<message>)
```

Supported email providers:
Gmail
Hotmail 
Yahoo

## Contributing

## Licence
